"use client";

import { useState, useMemo } from "react";
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingBag,
  Wallet,
  PiggyBank,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { sampleSalesData, formatCurrency, formatShortDate } from "@/lib/store";
import { cn } from "@/lib/utils";

type TimeRange = "today" | "week" | "month" | "year";

interface StatCardProps {
  title: string;
  value: string;
  change?: number;
  icon: React.ReactNode;
  trend?: "up" | "down";
  color: "primary" | "success" | "accent" | "destructive";
}

function StatCard({ title, value, change, icon, trend, color }: StatCardProps) {
  const colorClasses = {
    primary: "bg-primary/10 text-primary",
    success: "bg-success/10 text-success",
    accent: "bg-accent/10 text-accent",
    destructive: "bg-destructive/10 text-destructive",
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-5">
      <div className="flex items-start justify-between mb-4">
        <div className={cn("p-3 rounded-xl", colorClasses[color])}>{icon}</div>
        {change !== undefined && (
          <div
            className={cn(
              "flex items-center gap-1 text-sm font-medium px-2 py-1 rounded-full",
              trend === "up"
                ? "bg-success/10 text-success"
                : "bg-destructive/10 text-destructive"
            )}
          >
            {trend === "up" ? (
              <ArrowUpRight className="h-3 w-3" />
            ) : (
              <ArrowDownRight className="h-3 w-3" />
            )}
            {Math.abs(change)}%
          </div>
        )}
      </div>
      <p className="text-sm text-muted-foreground mb-1">{title}</p>
      <p className="text-2xl font-bold text-foreground">{value}</p>
    </div>
  );
}

export default function ReportPage() {
  const [timeRange, setTimeRange] = useState<TimeRange>("today");

  // Calculate statistics based on time range
  const stats = useMemo(() => {
    const now = new Date();
    const startOfDay = new Date(now.setHours(0, 0, 0, 0));
    const startOfWeek = new Date(now);
    startOfWeek.setDate(startOfWeek.getDate() - 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    let filterDate: Date;
    switch (timeRange) {
      case "today":
        filterDate = startOfDay;
        break;
      case "week":
        filterDate = startOfWeek;
        break;
      case "month":
        filterDate = startOfMonth;
        break;
      case "year":
        filterDate = startOfYear;
        break;
    }

    const filteredSales = sampleSalesData.filter(
      (sale) => new Date(sale.date) >= filterDate
    );

    const revenue = filteredSales.reduce((sum, sale) => sum + sale.total, 0);
    const cost = filteredSales.reduce(
      (sum, sale) =>
        sum +
        sale.items.reduce((itemSum, item) => itemSum + item.cost * item.quantity, 0),
      0
    );
    const profit = filteredSales.reduce((sum, sale) => sum + sale.profit, 0);
    const orders = filteredSales.length;

    return {
      revenue,
      cost,
      profit,
      orders,
      profitMargin: revenue > 0 ? ((profit / revenue) * 100).toFixed(1) : 0,
    };
  }, [timeRange]);

  // Get filtered sales for the table
  const filteredSales = useMemo(() => {
    const now = new Date();
    const startOfDay = new Date(now);
    startOfDay.setHours(0, 0, 0, 0);
    const startOfWeek = new Date(now);
    startOfWeek.setDate(startOfWeek.getDate() - 7);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    let filterDate: Date;
    switch (timeRange) {
      case "today":
        filterDate = startOfDay;
        break;
      case "week":
        filterDate = startOfWeek;
        break;
      case "month":
        filterDate = startOfMonth;
        break;
      case "year":
        filterDate = startOfYear;
        break;
    }

    return sampleSalesData.filter(
      (sale) => new Date(sale.date) >= filterDate
    );
  }, [timeRange]);

  const timeRangeLabels: Record<TimeRange, string> = {
    today: "Hôm nay",
    week: "7 ngày qua",
    month: "Tháng này",
    year: "Năm nay",
  };

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 rounded-xl p-3">
              <BarChart3 className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                Báo cáo doanh thu
              </h1>
              <p className="text-muted-foreground">
                Thống kê vốn, doanh thu và lợi nhuận
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <Select
              value={timeRange}
              onValueChange={(value) => setTimeRange(value as TimeRange)}
            >
              <SelectTrigger className="w-[160px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Hôm nay</SelectItem>
                <SelectItem value="week">7 ngày qua</SelectItem>
                <SelectItem value="month">Tháng này</SelectItem>
                <SelectItem value="year">Năm nay</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Doanh thu"
            value={formatCurrency(stats.revenue)}
            change={12.5}
            trend="up"
            icon={<DollarSign className="h-5 w-5" />}
            color="primary"
          />
          <StatCard
            title="Vốn (Chi phí)"
            value={formatCurrency(stats.cost)}
            change={8.2}
            trend="up"
            icon={<Wallet className="h-5 w-5" />}
            color="accent"
          />
          <StatCard
            title="Lợi nhuận"
            value={formatCurrency(stats.profit)}
            change={15.3}
            trend="up"
            icon={<PiggyBank className="h-5 w-5" />}
            color="success"
          />
          <StatCard
            title="Số đơn hàng"
            value={stats.orders.toString()}
            change={5.0}
            trend="up"
            icon={<ShoppingBag className="h-5 w-5" />}
            color="primary"
          />
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Daily Revenue */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-success" />
              Doanh thu theo ngày
            </h3>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const dayRevenue = sampleSalesData
                  .filter(
                    (s) =>
                      new Date(s.date).toDateString() === date.toDateString()
                  )
                  .reduce((sum, s) => sum + s.total, 0);

                return (
                  <div
                    key={i}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <span className="text-sm text-muted-foreground">
                      {formatShortDate(date.toISOString())}
                    </span>
                    <span className="font-medium text-foreground">
                      {formatCurrency(dayRevenue)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Monthly Revenue */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              Doanh thu theo tháng
            </h3>
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => {
                const date = new Date();
                date.setMonth(date.getMonth() - i);
                const monthNames = [
                  "Tháng 1", "Tháng 2", "Tháng 3", "Tháng 4", "Tháng 5", "Tháng 6",
                  "Tháng 7", "Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11", "Tháng 12"
                ];
                // Simulated monthly revenue
                const monthRevenue = Math.floor(Math.random() * 50000000) + 20000000;

                return (
                  <div
                    key={i}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <span className="text-sm text-muted-foreground">
                      {monthNames[date.getMonth()]} {date.getFullYear()}
                    </span>
                    <span className="font-medium text-foreground">
                      {formatCurrency(monthRevenue)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Profit Summary */}
          <div className="bg-card rounded-2xl border border-border p-5">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <PiggyBank className="h-4 w-4 text-success" />
              Tổng kết lợi nhuận
            </h3>
            <div className="space-y-4">
              <div className="bg-secondary/50 rounded-xl p-4">
                <p className="text-sm text-muted-foreground mb-1">
                  Tỷ suất lợi nhuận
                </p>
                <p className="text-3xl font-bold text-success">
                  {stats.profitMargin}%
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Doanh thu</span>
                  <span className="font-medium">{formatCurrency(stats.revenue)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Chi phí vốn</span>
                  <span className="font-medium text-destructive">
                    -{formatCurrency(stats.cost)}
                  </span>
                </div>
                <div className="h-px bg-border my-2" />
                <div className="flex justify-between">
                  <span className="font-semibold">Lợi nhuận ròng</span>
                  <span className="font-bold text-success">
                    {formatCurrency(stats.profit)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sales Table */}
        <div className="bg-card rounded-2xl border border-border p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground">
              Chi tiết đơn hàng - {timeRangeLabels[timeRange]}
            </h3>
            <Button variant="outline" size="sm">
              Xuất báo cáo
            </Button>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Mã đơn</TableHead>
                <TableHead>Ngày</TableHead>
                <TableHead>Sản phẩm</TableHead>
                <TableHead className="text-right">Doanh thu</TableHead>
                <TableHead className="text-right">Vốn</TableHead>
                <TableHead className="text-right">Lợi nhuận</TableHead>
                <TableHead>Thanh toán</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredSales.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    Không có dữ liệu trong khoảng thời gian này
                  </TableCell>
                </TableRow>
              ) : (
                filteredSales.map((sale) => {
                  const saleCost = sale.items.reduce(
                    (sum, item) => sum + item.cost * item.quantity,
                    0
                  );
                  return (
                    <TableRow key={sale.id}>
                      <TableCell className="font-medium">#{sale.id}</TableCell>
                      <TableCell>{formatShortDate(sale.date)}</TableCell>
                      <TableCell>
                        {sale.items.map((item) => item.productName).join(", ")}
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(sale.total)}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        {formatCurrency(saleCost)}
                      </TableCell>
                      <TableCell className="text-right text-success font-medium">
                        {formatCurrency(sale.profit)}
                      </TableCell>
                      <TableCell>
                        <span className="px-2 py-1 rounded-full text-xs bg-secondary">
                          {sale.paymentMethod}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
